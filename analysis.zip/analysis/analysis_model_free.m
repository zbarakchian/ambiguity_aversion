function output = analysis_model_free()
output = [];


