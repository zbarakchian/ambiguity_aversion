classdef model_class
    properties
        name
        description
        option
        parameters
        index
    end
    
    %fun, simulate
    
    methods
        % Constructor
        %------------------------------------------------------------------
        function thismodel = model_class(name,description,option)
            if nargin > 0
                thismodel.name = name;
                thismodel.description = description;
                thismodel.option = option;
            end
        end
        
        
        % getter
        %------------------------------------------------------------------
        function output = get.name(thismodel)
            output = thismodel.name;
        end

        function output = get.description(thismodel)
            output = thismodel.description;
        end
        
        function output = get.parameters(thismodel)
            output = thismodel.parameters;
        end
               
        function output = get.index(thismodel)
            output = thismodel.index;
        end
        
        % setter
        %------------------------------------------------------------------
        function thismodel = set.index(thismodel,indx)
            thismodel.index = indx;
        end
    end   
end

