classdef model3 < model_class
 
properties
end

methods        
%-constructor
%------------------------------------------------------------------
function thismodel = model3(name,description)
   if nargin > 0
        thismodel.name = name;
        thismodel.description = description;
        thismodel.parameters.name = {'beta0','beta1','beta2','beta3'};
        thismodel.parameters.num  = length(thismodel.parameters.name);
        thismodel.parameters.lb = [-Inf  -Inf -Inf -Inf];
        thismodel.parameters.ub = [+Inf  +Inf +Inf +Inf];

        inits.beta  = [1];
        
        initial_points = [];
        for b0 = inits.beta
        for b1 = inits.beta
        for b2 = inits.beta
        for b3 = inits.beta
            initial_points = [initial_points; [b0 b1 b2 b3]];
        end
        end
        end
        end
        thismodel.parameters.inits = initial_points;
   end
end

%-likelihood function
%--------------------------------------------------------------------------       
function negloglik = func(thismodel,params,args)
    beta0   = params(1);                                                     
    beta1   = params(2);                                                     
    beta2   = params(3);                                                     
    beta3   = params(4);                                                     
   %----------------------------------------------------------------------
    choice          = args.choice;       
    C               = args.C;    
    A               = args.A;  
    m               = args.m;    
    n               = args.n;    
    k               = args.k;    
    p_bayes         = args.p_bayes;  
    uIndx           = args.uIndx;
    aIndx           = args.aIndx;
    %----------------------------------------------------------------------     
    a1 = 1+k; b1 = 1+n-k;
    mu1 = a1 ./ (a1+b1); %bayesian version    

    pa_hidden   = mu1;  % ambiguous urn in ambiguous trials
    pa_revealed = k./n;
    pa_total    = (pa_hidden.*(50-n) + pa_revealed.*n)/50;
    
    pa(uIndx,1) = p_bayes(uIndx,2); 
    pa(aIndx,1) = pa_total(aIndx);
    pu = p_bayes(:,1);

    pdif  = pa - pu;
    pdifz = zscore(pdif);    

    mdif = m(:,2) - m(:,1);
    mdifz = zscore(mdif);
    
    Az = zscore(A);
    
    regression  = - (beta0 * C + beta1 * mdifz + beta2 * pdifz + beta3 * Az);
    punambig    = 1./(1 + exp(regression));
    
    lik         = (choice == 1) .* punambig + (choice == 0) .* (1-punambig);
    logp        = log(lik);
    index       = find(~isnan(choice)); 
    negloglik   = -sum(logp(index));
    %index       = logp == -Inf; %sum(index)  %This line is the same as the above line
    %negloglik   = -sum(logp(index == 0));
end

%-likelihood function
%--------------------------------------------------------------------------       
function output = simulate(thismodel,params,args)
    beta0   = params(1);                                                     
    beta1   = params(2);                                                     
    beta2   = params(3);                                                     
    beta3   = params(4);                                                     
   %----------------------------------------------------------------------
    C               = args.C;    
    A               = args.A;  
    m               = args.m;    
    n               = args.n;    
    k               = args.k;    
    p_bayes         = args.p_bayes;  
    uIndx           = args.uIndx;
    aIndx           = args.aIndx;
    %----------------------------------------------------------------------     
    a1 = 1+k; b1 = 1+n-k;
    mu1 = a1 ./ (a1+b1); %bayesian version    

    pa_hidden   = mu1;  % ambiguous urn in ambiguous trials
    pa_revealed = k./n;
    pa_total    = (pa_hidden.*(50-n) + pa_revealed.*n)/50;
    
    pa(uIndx,1) = p_bayes(uIndx,2); 
    pa(aIndx,1) = pa_total(aIndx);
    pu = p_bayes(:,1);

    pdif  = pa - pu;
    pdifz = zscore(pdif);    

    mdif = m(:,2) - m(:,1);
    mdifz = zscore(mdif);
    
    Az = zscore(A);
    
    regression  = - (beta0 * C + beta1 * mdifz + beta2 * pdifz + beta3 * Az);
    punambig    = 1./(1 + exp(regression));

    p_coinflip = rand(200,1);
    choice = 1 * (p_coinflip <= punambig) + 0 * (p_coinflip > punambig); %choosing unambiguous, left urn    
    output = choice;           
end

end
end