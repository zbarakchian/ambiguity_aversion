classdef modelEU1 < model_class
% Model 02: Expected Utility, baseline
 
properties
end

methods        
%-constructor
%------------------------------------------------------------------
function thismodel = modelEU1(name,description)
   if nargin > 0
        thismodel.name = name;
        thismodel.description = description;
        thismodel.parameters.name = {'beta1','lambda'};
        thismodel.parameters.num  = length(thismodel.parameters.name);
        thismodel.parameters.lb = [-Inf 0];
        thismodel.parameters.ub = [ Inf 1];

        inits.beta1  = 1;%[1:1:3];
        inits.lambda = .5;%[0:.5:1]; 
        
        initial_points = [];
        for b1 = inits.beta1
        for l = inits.lambda
            initial_points = [initial_points; [b1 l]];
        end
        end
        thismodel.parameters.inits = initial_points;
   end
end

%-likelihood function
%--------------------------------------------------------------------------       
function negloglik = func(thismodel,params,args)
    beta1   = params(1);                                                     
    lambda  = params(2);    
    %----------------------------------------------------------------------
    choice          = args.choice;       
    C               = args.C;    
    A               = args.A;  
    m               = args.m;    
    n               = args.n;    
    k               = args.k;    
    p_bayes         = args.p_bayes;  
    uIndx           = args.uIndx;
    aIndx           = args.aIndx;
    %----------------------------------------------------------------------     
    a1 = 1+k; b1 = 1+n-k;
    mu1 = a1 ./ (a1+b1); %bayesian version    

    pa_hidden   = mu1;  % ambiguous urn in ambiguous trials
    pa_revealed = k./n;
    pa_total    = (pa_hidden.*(50-n) + pa_revealed.*n)/50;
    
    pa(uIndx,1) = p_bayes(uIndx,2); 
    pa(aIndx,1) = pa_total(aIndx);
    pu = p_bayes(:,1);
 
    EU1         = m(:,1).^lambda .* pu;
    EU2         = m(:,2).^lambda .* pa;
    EUdif       = EU2 - EU1;
    regression  = - beta1 * (EUdif);
    punambig    = 1./(1 + exp(regression));
    
    %pbinomial  = binopdf(200-nansum(choice),200,punambig);%TODO! WRONG!!! it should be bernouli, not binomial... because the punambig is different in each trial.
    lik         = (choice == 1) .* punambig + (choice == 0) .* (1-punambig);
    logp        = log(lik);
    index       = find(~isnan(choice)); 
    negloglik   = -sum(logp(index));
    %index      = logp == -Inf; %sum(index)  %This line is the same as the above line
    %negloglik  = -sum(logp(index == 0));
end


%-simulation function
%--------------------------------------------------------------------------       
function output = simulate(thismodel,params,args,ntrials)
    beta1   = params(1);                                                     
    lambda  = params(2);    
    %----------------------------------------------------------------------
    C               = args.C;    
    A               = args.A;  
    m               = args.m;    
    n               = args.n;    
    k               = args.k;    
    p_bayes         = args.p_bayes;  
    uIndx           = args.uIndx;
    aIndx           = args.aIndx;
    %----------------------------------------------------------------------     
    a1 = 1+k; b1 = 1+n-k;
    mu1 = a1 ./ (a1+b1); %bayesian version    

    pa_hidden   = mu1;  % ambiguous urn in ambiguous trials
    pa_revealed = k./n;
    pa_total    = (pa_hidden.*(50-n) + pa_revealed.*n)/50;
    
    pa(uIndx,1) = p_bayes(uIndx,2); 
    pa(aIndx,1) = pa_total(aIndx);
    pu = p_bayes(:,1);
 
    EU1         = m(:,1).^lambda .* pu;
    EU2         = m(:,2).^lambda .* pa;
    EUdif       = EU2 - EU1;
    regression  = - beta1 * (EUdif);
    punambig    = 1./(1 + exp(regression));
    
    p_coinflip = rand(200,1);
    choice = 1 * (p_coinflip <= punambig) + 0 * (p_coinflip > punambig); %choosing unambiguous, left urn    
    output = choice;                  
end

%%
function simulate2(thismodel,args,ntrials)
%     m       = args.m;    
%     p       = args.p;
%     %----------------------------------------------------------------------
%     betas  = -5:0.1:5;                                                     
%     lambdas = 0.1;%0:0.1:1;
%     
%     for beta = betas
%     for lambda = lambdas
%         for t = 1:ntrials 
%             EU1(t)       = m(t,1)^lambda * p(t,1);
%             EU2(t)       = m(t,2)^lambda * p(t,2);
%             regression   = - beta * (EU2(t) - EU1(t));
%             pambiguous(t)= 1./(1 + exp(regression));
%         end        
% %         subplot(2,1,1)
% %         plot(EU2,'r');
% %         hold on;
% %         plot(EU1,'b');
% %         title(['lambda = ' num2str(lambda), ' beta = ' num2str(beta)]);
% % 
% %         subplot(2,1,2)
% %         plot(EU2-EU1,'k');
% % 
% %         disp('good!');
%         
%         plot(pambiguous,'k');
%         title(['lambda = ' num2str(lambda), ' beta = ' num2str(beta)]);
%         disp('good!');
%     end
%     end

    beta = 01;
    x = [-10:0.1:10];
    p = 1./(1 + exp(- beta .* x));
    plot(x,p);
    
end


end
end



%%
% function negloglik = model2(beta,lambda,m,p,choice)
%     EU1        = (m(:,1).^lambda) .* p(:,1);
%     EU2        = (m(:,2).^lambda) .* p(:,2);
%     p          = 1./(1 + exp(-beta * (EU2 - EU1)));
%     k          = sum(choice);
%     n          = 200;
%     %negloglik  = -sum(log(binopdf(k,n,p)));
%     try
%     loglik     = log(nchoosek(n,k)) + k*log(p) + (n-k)*log(1-p);
%     negloglik  = -sum(loglik);
%     catch
%         negloglik = 0;
%     end


