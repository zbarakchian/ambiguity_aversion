function params = get_params(addr,sbjs,models)

nmodel = length(models);
params = [];
for m = 1:nmodel
    model = models{m};
    load([addr filesep 'fitting_' model.name]);
    
    for sub = sbjs
        params.(model.name)(sub,:) = data_fit{sub}.params;
    end
end