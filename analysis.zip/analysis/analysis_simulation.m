function analysis_simulation(addr,models)

nmodel = length(models);
args   = get_args(addr,1);

for m = 1:nmodel
    model = models{m};  
    
    params = [1,1,0.01]; 
    output = model.simulate(params,args); 
    histogram(output);
    
end
