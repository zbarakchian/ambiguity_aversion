function output = analysis_model_based(addr,sbjs,models)
output = [];



do_model_fitting            = 1;  % Do the model fitting procedure!
do_analyze_params           = 0;  % check the fitted parameters!
do_goodnessOfFit            = 0;  % Calculate the negative log-likelihoods and corresponding AIC/BIC and Exceedance Probability. 
do_parameter_recovery       = 0;  % Do the parameter recovery procedure!
do_mdoel_identification     = 0;  % Do the model recovery procedure!
do_simulation_pure          = 0;  % Simulate the model (pure: setting params manually and unrelated to the fitted params. Just to see how does the model work)




%==========================================================================
if do_model_fitting
        
analysis_model_fitting(addr,sbjs,models);

end

if do_analyze_params
    
analysis_parameters(addr,sbjs,models);

end



%==========================================================================
if do_parameter_recovery
    
analysis_parameter_recovery(addr,sbjs,models);

end



%==========================================================================
if do_mdoel_identification
    
analysis_model_identification();%addr,sbjs,models_gen,models_fit

end






%==========================================================================
if do_goodnessOfFit
    
analysis_goodnessOfFit(addr,sbjs,models);

end





%==========================================================================
if do_simulation_pure
    
analysis_simulation(addr,models);

end



