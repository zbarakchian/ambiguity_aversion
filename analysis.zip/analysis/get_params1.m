function params = get_params1(sbjs,data)

params = [];  
for sub = sbjs
    params(sub,:) = data{sub}.params;
end
