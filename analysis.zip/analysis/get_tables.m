function [tbl,tblu,tbla] = get_tables(addr,sub)


args            = get_args(addr,sub); 
uIndx           = args.uIndx;
aIndx           = args.aIndx;
choice          = args.choice;
C               = args.C;
A               = args.A;
m               = args.m;
p               = args.p;
p_bayes         = args.p_bayes; %p and p_bayes are equal
p_pess          = args.p_pess;
p_opt           = args.p_opt;


%%
mdif(:,1)       = m(:,2) - m(:,1);
pdif(:,1)       = p(:,2) - p(:,1); 
logmodul        = sign(pdif) .* log(abs(pdif)+1); %log modulus
pdif_bayes      = pdif;
logmodul_bayes  = logmodul;
pdif_pess(:,1)  = p_pess(:,2) - p_pess(:,1); %pessimistic
logmodul_pess   = sign(pdif_pess) .* log(abs(pdif_pess)+1);


%-nominaliA_ztion by zscore
mdif_z          = zscore(mdif);
pdif_z          = zscore(pdif);
logmodul_z      = zscore(logmodul);
logmodul_pess_z = zscore(logmodul_pess);
A_z             = zscore(A);
C               = nominal(C);

%-creating the table for regression
tbl  = table(choice,  mdif_z,  pdif_z,  logmodul_z,  logmodul_pess_z, C,  A_z,   'VariableNames',...
           {'choice','mdif_z','pdif_z','logmodul_z','logmodul_pess_z','C','A_z'});
       
%%
%-Two separate tables for ambiguous and un-ambiguous trials:
choice_u      = choice(uIndx);
choice_a      = choice(aIndx);
C_u           = C(uIndx);
C_a           = C(aIndx);
A_u           = A(uIndx);
A_a           = A(aIndx);
m_u           = m(uIndx,:);
m_a           = m(aIndx,:);
p_u           = p(uIndx,:);
p_a           = p(aIndx,:);
mdif_u(:,1)   = m_u(:,2) - m_u(:,1);
mdif_a(:,1)   = m_a(:,2) - m_a(:,1);
pdif_u(:,1)   = p_u(:,2) - p_u(:,1); 
pdif_a(:,1)   = p_a(:,2) - p_a(:,1); 
logmodul_u  = sign(pdif_u) .* log(abs(pdif_u)+1);
logmodul_a  = sign(pdif_a) .* log(abs(pdif_a)+1);
pa_a          = p_a(:,2);
Apa_a         = A_a .* pa_a;

%-nominaliA_ztion by zscore
mdif_uz       = zscore(mdif_u);
mdif_az       = zscore(mdif_a);
pdif_uz       = zscore(pdif_u);
pdif_az       = zscore(pdif_a);
logmodul_uz = zscore(logmodul_u);
logmodul_az = zscore(logmodul_a);
A_uz          = zscore(A_u);
A_az          = zscore(A_a);
C_u           = nominal(C_u);
C_a           = nominal(C_a);
Apa_az        = zscore(Apa_a);


tblu = table(choice_u,  mdif_uz,  pdif_uz,  logmodul_uz,  C_u,  A_uz,   'VariableNames',...
           {'choice_u','mdif_uz','pdif_uz','logmodul_uz','C_u','A_uz'});
       
tbla = table(choice_a,  mdif_az,  pdif_az,  logmodul_az,  C_a,  A_az,  Apa_az,  'VariableNames',...
           {'choice_a','mdif_az','pdif_az','logmodul_az','C_a','A_az','Apa_az'});
