function analysis_model_fitting(addr,sbjs,models)

nmodels = length(models);
for m = 1:nmodels
    model = models{m};
    for sub = sbjs  
        disp(['subject ' num2str(sub) ' ---------------'] );
        args = get_args(addr,sub);
        data_fit{sub} = Minimize(sub,model,args);
    end
    
    save([addr.fit filesep 'fitting_' model.name],'data_fit');
end







