function analysis_parameter_recovery(addr,sbjs,models)


do_simulation_fitting   = 1;
do_report_correlation   = 0;
do_plot_datapoints      = 0;
do_regression           = 0;
do_plot_regression      = 0;
do_plot_confusion       = 0;


%--------------------------------------------------------------------------
nitr   = 10;
nmodel = length(models);


%% 
if do_simulation_fitting
    
params = get_params(addr.fit,sbjs,models);
for  m = 1:nmodel   
    model = models{m};     
    
    param1  = params.(model.name);
    agents  = 1:size(param1,1);    

    for itr = 1:nitr  
        
        parameters.gen = param1;
        for sub = agents  
            tic
            
            disp(['iteration ' int2str(itr) ' .................'])
            arguments        = get_args(addr,1);
            choice{sub}      = model.simulate(param1(sub,:),arguments);    
            arguments.choice = choice{sub};
            data_fit{sub}    = Minimize(sub,model,arguments);
            
            toc 
            time.(model.name) = toc;
        end  
        parameters.fit       = get_params1(agents,data_fit);

        data{itr}.choice     = choice;
        data{itr}.params     = parameters;
        data{itr}.data_fit   = data_fit;
    end
    %-saving simulated and fitted data
    disp(['saving the data for parameter recovery procedure... ' model.name]);
    save([ addr.precovery filesep 'fitting_' model.name],'data');

end
end
 
disp('Here!');

%% data for regression
data_reg = [];
for m = 1:nmodel  
    model  = models{m};
    load([addr.precovery filesep 'fitting_' model.name '.mat']); 
    
    for itr = 1:nitr 
       params = data{itr}.params;
       
       np = model.parameters.num;
       ns = length(params.gen(:,1)); %31;
       
      for p = 1:np             
           ibegin = ((itr-1) * np * ns + (p-1) * ns + 1);
           iend   = ibegin + ns - 1;
           
           reg.old(ibegin:iend, 1) = params.gen(:,p);
           reg.new(ibegin:iend, 1) = params.fit(:,p);
           reg.sbj(ibegin:iend, 1) = 1:ns;
           reg.num(ibegin:iend, 1) = repmat(p,ns,1);
       end
    end      
    data_reg{m} = reg;                  
end


%%
if do_report_correlation || do_plot_confusion
    
%-prepare the data: individual iterations
% averaged iterations: create a pairs of columns to enetr the correlation formula
param_indv = [];
param_avrg = [];
for m = 1:nmodel
    model  = models{m};
    load([addr.precovery filesep 'fitting_' model.name '.mat']);       
    
    for p = 1:model.parameters.num      
      tmp = [];
      for itr = 1:nitr       
            params = data{itr}.params;
            tmp.old(:,itr) = params.gen(:,p);
            tmp.new(:,itr) = params.fit(:,p);
      end
      param_indv{m,p} = tmp;

      tmp.old = mean(tmp.old,2);
      tmp.new = mean(tmp.new,2);
      param_avrg{m,p} = tmp;                  
    end  
end


%-paired ttest
pvalues = [];
for m = 1:nmodel   
    model = models{m};
    nparams = model.parameters.num;
    
    for p = 1:nparams
        [h,pval,ci,stats] = ttest(param_avrg{m,p}.old, param_avrg{m,p}.new);
        %[h,pval,ci,stats] = ttest(param_indv{m,p}.old, param_indv{m,p}.new);
        pvalues{m}(p)  = pval;
    end
end

%correlation on average(over iteration)
correlation = [];
for m = 1:nmodel   
    model = models{m};
    nparams = model.parameters.num;
    
    for p1 = 1:nparams
        for p2 = 1:nparams            
            [RHO,PVAL]  = corr(param_avrg{m,p1}.old, param_avrg{m,p2}.new);
            %[RHO,PVAL]  = corr(param_indv{m,p1}.old', param_indv{m,p2}.new');
            correlation{m}(p1,p2,:) = [RHO, PVAL];
        end
    end
    disp(correlation{m}(:,:,1));
end
end



%%
if do_plot_datapoints
%-scatter plot


for m = 1:nmodel              
    model  = models{m};
    nparams = model.parameters.num;

    old = data_reg{m}.old;
    new = data_reg{m}.new;
    sbj = data_reg{m}.sbj;
    num = data_reg{m}.num;

    f = figure;                    
    for p = 1:nparams  
        %ax = subplot(nparams,1,p); 
        ax = subplot(4,2,p); 
        
        indx1 = find(num == p);  
        
        pname = model.parameters.name{p};  
        
        x = old(indx1);
        y = new(indx1);
        scatter(x,y,'o','b');

        h = lsline(ax);
        h.Color = 'r';
        h.LineWidth = 5;

        hold on
        plot(x,x,'--k','LineWidth',5);
            
        pname = model.parameters.name{p}; 
        if     contains(pname,'beta')
            pname = '\beta';
        elseif contains(pname,'alpha')
            pname = '\alpha';
        elseif contains(pname,'lambda')
            pname = '\lambda';
        end
        

        tit = [ pname ];
        title(tit);  
    end  
    
    %set(gca,'FontName','Times New Roman','FontSize', 14);        

    name = ['figs' filesep 'precovery_' model.name '.png'];
    saveas(gcf,name);
    close(f);
        
end
end



%%
if do_regression || do_plot_regression
%scatter plot of regression

  
%-Regression: General Linear Mixed model (Fixed effect + Random effect): fitlme
for m = 1:nmodel 
    model  = models{m};
    nparams = model.parameters.num;
    
    %----------------------------------------------------------------------        
    for p = 1:nparams
        
        num  = data_reg{m}.num;
        indx1 = find(num == p);
        
        old = data_reg{m}.old(indx1);
        new = data_reg{m}.new(indx1);
        sbj = data_reg{m}.sbj(indx1);

        %-nominal-ization and normal-ization: z-score
        sbj  = nominal(sbj);       
        tbl  = table(old,  new,  sbj, 'VariableNames',...
                   {'old','new','sbj'});
                       
        modelspec = 'new ~ 1 + old';
        output{m,p} = fitlm(tbl,modelspec); %'Verbose',2

        disp(output{m,p});
    end
end
end


%%
if do_plot_regression


%-scatter plot
for m = 1:nmodel              
    model  = models{m};
    nparams = model.parameters.num;

    old = data_reg{m}.old;
    new = data_reg{m}.new;
    sbj = data_reg{m}.sbj;
    num = data_reg{m}.num;

    figure;                    
    for p = 1:nparams  
        subplot(nparams,1,p); 
        
        indx1 = find(num == p);        
        x = old(indx1);
        y = new(indx1);
        scatter(x,y,'o','b');
        lsline;
        
        switch p
        case {1}
            xlimit = [0 4];  ylimit = [0 4];              
        case {2}               
            xlimit = [0 6];  ylimit = [0 6];               
        case {3}               
            xlimit = [0 1];  ylimit = [0 1];                    
        case {4}               
            xlimit = [0 8];  ylimit = [0 8];        
        end
        xlim(xlimit); ylim(ylimit);

        
        pname = model.parameters.name{p}; 
        if     contains(pname,'beta')
            pname = '\beta';
        elseif contains(pname,'alpha')
            pname = '\alpha';
        elseif contains(pname,'lambda')
            pname = '\lambda';
        end
        
        str = model.name;  
        modelname = strrep(str,'_','');

        tit = [ pname ' - (' modelname ')'];
        title(tit);          
    end   
    %set(gca,'FontName','Times New Roman','FontSize', 14);        
end
end



%%
if do_plot_confusion %confusion matrix
    
for m = 1:nmodel   
    model = models{m};
    nparams = model.parameters.num;

    f = figure;

    matrix = correlation{m}(end:-1:1,:,1);
    
    xvalues = model.parameters.name; 
    for i = 1:nparams
        if isequal(xvalues{i}, 'beta')
            xvalues{i} = '\beta';
        elseif isequal(xvalues{i}, 'alpha')
            xvalues{i} = '\alpha';
        elseif isequal(xvalues{i}, 'alpha1')
            xvalues{i} = '\alpha_1';
        elseif isequal(xvalues{i}, 'alpha2')
            xvalues{i} = '\alpha_2';
        end
    end
    yvalues = flip(xvalues);

    h = heatmap(xvalues, yvalues, matrix, 'FontSize', 14,'ColorLimits',[-1 1]);

    colorbar;
    greenColorMap = [zeros(1, 132), linspace(0, 1, 124)]; %% Create colormap that is green for negative, red for positive,and a chunk inthe middle that is black.
    redColorMap = [linspace(1, 0, 124), zeros(1, 132)];
    colorMap = [redColorMap; greenColorMap; zeros(1, 256)]';
    colormap(colorMap); % Apply the colormap.
    
    
    h.Title  = 'Pearson Correlation';
    h.YLabel = 'Generated Parameter';
    h.XLabel = 'Fitted Parameter';
    
    set(gca,'FontName','Times New Roman','FontSize', 14);
    
    name = ['figs' filesep 'precovery_confusion_' model.name '.png'];
    saveas(gcf,name);
    close(f);
end
end


