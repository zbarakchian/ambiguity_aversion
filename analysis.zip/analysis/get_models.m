function models = get_models()

addpath(genpath([pwd, filesep, 'models' ]));

%% Model definition

model1log1          = model1_log_1('model_1log_1','Additive, baseline');                
model1log0          = model1('model_1','Additive, baseline');                
model1VaR           = model1_VaR('model_1VaR',[]); 
model1CVaR          = model1_CVaR('model_1CVaR',[]); 
model1ShapeM        = model1_ShapeM('model_1Shape_M',[]); 
model1ShapeK        = model1_ShapeK('model_1Shape_K',[]); 
model1ShapeMVaR     = model1_ShapeM_VaR('model_1Shape_MVaR',[]); 
model1ShapeMCVaR    = model1_ShapeM_CVaR('model_1Shape_MCVaR',[]); 
model1ShapeKVaR     = model1_ShapeK_VaR('model_1Shape_KVaR',[]); 
model1ShapeKCVaR    = model1_ShapeK_CVaR('model_1Shape_KCVaR',[]); 

model2VaR           = model2_VaR('model_2VaR',[]); %no b3 
model2CVaR          = model2_CVaR('model_2CVaR',[]); 
model2ShapeM        = model2_ShapeM('model_2Shape_M',[]); 
model2ShapeK        = model2_ShapeK('model_2Shape_K',[]); 
model2ShapeMVaR     = model2_ShapeM_VaR('model_2Shape_MVaR',[]); 
model2ShapeMCVaR    = model2_ShapeM_CVaR('model_2Shape_MCVaR',[]); 
model2ShapeKVaR     = model2_ShapeK_VaR('model_2Shape_KVaR',[]); 
model2ShapeKCVaR    = model2_ShapeK_CVaR('model_2Shape_KCVaR',[]); 


model3log1          = model3_log_1('model_3log1','Additive, baseline plus ...');       
model3log0          = model3('model_3','Additive, baseline plus ...');       
model3VaR           = model3_VaR('model_3VaR',[]); 
model3CVaR          = model3_CVaR('model_3CVaR',[]); 


modelEU1Emma        = modelEU1('modelEU1','Expected Utility, baseline');        
modelEU1VaR         = modelEU1_VaR('modelEU1VaR',[]); 
modelEU1CVaR        = modelEU1_CVaR('modelEU1CVaR',[]); 
modelEU1ShapeM      = modelEU1_ShapeM('modelEU1ShapeM',[]); 

modelEU2Emma        = modelEU2('modelEU2','Expected Utility baseline plus ..'); 
modelEU2VaR         = modelEU2_VaR('modelEU2VaR',[]); 
modelEU2CVaR        = modelEU2_CVaR('modelEU2CVaR',[]); 
modelEU2ShapeM      = modelEU2_ShapeM('modelEU2ShapeM',[]); 

%%
models   = {
        model1log1 , ...            %1    
        model1log0 , ...            %2 
        model1VaR , ...             %3 
        model1CVaR , ...            %4 
        model1ShapeM , ...          %5 
        model1ShapeK , ...          %6 
        model1ShapeMVaR  , ...      %7 
        model1ShapeMCVaR , ...      %8 
        model1ShapeKVaR , ...       %9 
        model1ShapeKCVaR , ...      %10 
        model2VaR  , ...            %11
        model2CVaR  , ...           %12
        model2ShapeM  , ...         %13
        model2ShapeK  , ...         %14
        model2ShapeMVaR   , ...     %15
        model2ShapeMCVaR   , ...    %16
        model2ShapeKVaR    , ...    %17
        model2ShapeKCVaR  , ...     %18
        model3log1  , ...           %19        
        model3log0  , ...           %20       
        model3VaR   , ...           %21        
        model3CVaR  , ...           %22      
}; 
                 
         
         
