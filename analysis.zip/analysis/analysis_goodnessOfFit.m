function analysis_goodnessOfFit(addr,sbjs,models)
%gof: 1:lik, 2:aic, 3:bic, 4:xp, 5:pxp

do_overall      = 1;    gof1 = [1,2,3,4,5];  %you can use 1:5        
do_indv         = 0;    gof2 = [1,2,3];      %you can use only 1:3         
do_indv_heat    = 0;    gof3 = [1,2,3];      %you can use only 1:3        


%% pre
nsbjs    = length(sbjs);
nmodels  = length(models);


if nmodels < 10 
    fsize = 16;
    angle = 45;
else
    fsize = 13;
    angle = 90;
end


ntrials = 200;
for m = 1:nmodels
    model = models{m};
    data{m} = load([addr.fit filesep 'fitting_', model.name,'.mat']); %data_fit
    criterion{m} = get_likbic(sbjs,model,data{m},ntrials);
end

for m = 1:nmodels
    cri = criterion{m};
    for sub = sbjs
        lik(sub,m) = cri{sub}.lik;
        aic(sub,m) = cri{sub}.aic;
        bic(sub,m) = cri{sub}.bic;
    end
end


for m = 1:nmodels 
    xvalues{1,m} = models{m}.name;        
end

%%
if do_overall
%lik,aic,bic,xp,pxp
len_gof1 = length(gof1);
   

%--------------------------------------------------------------------------
use_bic = 1;
bms_results = exceedance_probability(sbjs,models,use_bic,criterion);


%--------------------------------------------------------------------------
lik_results = mean(lik,1);
aic_results = mean(aic,1);
bic_results = mean(bic,1);

lik_sem = std(lik,1,1) ./ sqrt(nsbjs);
aic_sem = std(aic,1,1) ./ sqrt(nsbjs);
bic_sem = std(bic,1,1) ./ sqrt(nsbjs);


f = figure;
for i = 1:len_gof1
    
switch(gof(i))
    case 1
        result = lik_results;
        result = result - min(result);
        sem = lik_sem;
        tit = 'lik';
    case 2
        result = aic_results; 
        result = result - min(result);
        sem = aic_sem;
        tit = 'aic';
    case 3
        result = bic_results; 
        result = result - min(result);
        sem = bic_sem;
        tit = 'bic';
    case 4        
        result = bms_results.xp;
        tit = 'xp';
        disp(bms_results); 
    case 5       
        result = bms_results.pxp;
        tit = 'pxp';
        disp(bms_results); 
end


if (len_gof1 > 1)
    subplot(1,len_gof1,i);
end

b = bar(result,'FaceColor',[.5 .5 .5]);

switch(gof(i))
    case {1,2,3}
    hold on
    x = 1:length(result);
    e = errorbar(x,result,sem,'o');
end


xticks(1:length(result)); %xvalues
xticklabels(xvalues);
xtickangle(angle);
title(tit);
% xlabel('Models');%,'FontSize',3

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',fsize);

% set(gca,'FontName','Times New Roman','FontSize', 8);        
end

name = ['figs' filesep 'gof_overall' '.png'];
saveas(gcf,name);
close(f);


end


%% indv
if do_indv_heat
% lik,aic,bic;
len_gof2 = length(gof2);

f = figure;
for i = 1:len_gof2
    
yvalues = sbjs; 
for m = 1:nmodels       
    modelname = models{m}.name;
    nametoshow = modelname;
    xvalues{m} = nametoshow; 
end

 

switch(gof(i))
    case 1
        result = lik;
        tit = 'lik';
    case 2
        result = aic; 
        tit = 'aic';
    case 3
        result = bic; 
        tit = 'bic';        
end

if (len_gof2 > 1)
    subplot(1,len_gof2,i);
end

heatmap(xvalues, yvalues,result,'FontSize', fsize);%,'ColorLimits',[0 1]);
% heatmap(1:nmodels, yvalues,result,'FontSize', 10);%,'ColorLimits',[0 1]);
% colormap(flipud(gray));
ylabel('Subject');
xlabel('Model');
title(tit);
set(gca,'FontName','Times New Roman');


end

name = ['figs' filesep 'gof_indv1' '.png'];
saveas(gcf,name);
close(f);

end


%--------------------------------------------------------------------------
if do_indv
% lik,aic,bic;
len_gof3 = length(gof3);


f = figure;
for i = 1:len_gof3
switch(gof(i))
    case 1
        result = lik;
        tit = 'lik';
    case 2
        result = aic; 
        tit = 'aic';
    case 3
        result = bic; 
        tit = 'bic';        
end

data_01 = [];
for sub = sbjs        
    [m,indx] = min(result(sub,:));
    tmp = zeros(1,nmodels); tmp(indx) = 1;        
    data_01(sub,:) = tmp;       
end
freq = squeeze(mean(data_01,1));


if (len_gof3 > 1)
    subplot(1,len_gof3,i);
end

b = bar(freq,'FaceColor',[.5 .5 .5]);

title(tit);

xticks(1:length(freq)); %xvalues
xticklabels(xvalues); %1:length(freq));
xtickangle(angle);
% xlabel('Models','FontSize',12);
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',fsize);

% set(gca,'FontName','Times New Roman','FontSize', 10);        
end

name = ['figs' filesep 'gof_indv2' '.png'];
saveas(gcf,name);
close(f);


end












