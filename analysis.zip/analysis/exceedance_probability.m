function bms_results = exceedance_probability(sbjs,models,use_bic,criterion)
%-Bayesian Model Comparison: Exceedance Probability
%%%---gershman mfit-master

nmodel = length(models);

lme  = [];
lme0 = [];
bms_results = [];
for m = 1:nmodel
    model = models{m};
    K = model.parameters.num;
    for sub = sbjs
        %lme0(sub,m) = -0.5 * criterion{m}{sub}.lik;  
        lme0(sub,m) = -0.5 * criterion{m}{sub}.bic;         
    end
    logpost = [];
    for sub = sbjs
        h(sub,1) = log(det(criterion{m}{sub}.hessian)); 
        logpost(sub,1) = - criterion{m}{sub}.lik; 
    end
    lme(:,m) = logpost(sbjs) + 0.5 * (K * log(2*pi) - h(sbjs));
end

ix = isnan(lme)|isinf(lme)|imag(lme)~=0; % use BIC if any Hessians are degenerate
if any(ix(:))
    lme = lme0;
end
if use_bic==1; lme = lme0; end

lme(any(isnan(lme)|isinf(lme),2),:) = [];

[bms_results.alpha, bms_results.exp_r, bms_results.xp, bms_results.pxp, bms_results.bor] = bms(lme);


