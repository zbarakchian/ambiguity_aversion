clear;

%-SetUp
%--------------------------------------------------------------------------
addr        = get_address();
sbjs        = get_sbjs();
nsbjs       = length(sbjs);
models_all  = get_models();


%-Please Specify which analysis do you want to do!!!!
%--------------------------------------------------------------------------
do_analysis_model_free      = 0;  % Do the behavioral analysis!
do_analysis_model_based     = 1;  % Do the modeling analysis!


%Please Specify your config!!!!!
%--------------------------------------------------------------------------
modelsN     = [1,2]; 
models      = models_all(modelsN);


% _______
% ______ (�`v��)
% ______(�`(?)��)__(�`v��)
% _______(_.^._)__(�`(?)��)
% _________(�`v��)�(_.^._)
% ________(�`(?)��)(�`v��)
% _________(_.^._)(�`(?)��)
% ________________ (_.^._)


%==========================================================================
if do_analysis_model_free
    
output = analysis_model_free();

end


%==========================================================================
if do_analysis_model_based
    
analysis_model_based(addr,sbjs,models);

end



disp('END!');


    