function args = get_args(addr,sub)
load([addr.data filesep 'data.mat']);

choice  = Trials{sub}.BetParticipantChoice1choserighturn;
outcome = Trials{sub}.OutcomeforCurrentTrial1ifOselectedfromurn0ifXselectedfromurn;
AL      = Trials{sub}.AmbiguityLevel;  %proportions of revealed tokens in the ambihuous urns in the ambiguous trials
m1      = Trials{sub}.MagnitudeLeftUrn;
m2      = Trials{sub}.MagnitudeRightUrnAmbigUrnonAmbigTrials;
p1      = Trials{sub}.ProportionNoughtsLeftUrn;
p2      = Trials{sub}.ProportionNoughtsRightUrnAmbigUrnonAmbigTrials; %=|O|/50
po      = Trials{sub}.ProportionNoughtsinRevealedTokensforAmbigUrn; %=k/n
C       = Sides.Ambig1ifambiguoustrial0ifunambiguoustrial;

%%
notnan = ~isnan(choice);
choice(notnan) = ~choice(notnan);     %flip right urn (ambiguous urn) to left urn (unambiguous urn), so that hereafter choice is for choosing unambiguous urn 


aIndx   = find(C == 1);
uIndx   = find(C == 0);
m       = [m1,m2]; %left = 1, right = 2


n = AL*50; %numebr of revealed tokens %the level of missing information was varied evenly across 8 levels (number of occluded tokens = 10, 30, 40, 45, 46, 47, 48 or 49 out of 50). 
A = 1-sqrt(n./50);
 
k = po.*n;  
a = 1+k;    
b = 1+n-k; 

pu = p1;                 % un-ambiguous urn in ambiguous trials
pa_hidden   = a./(a+b);  % ambiguous urn in ambiguous trials
pa_revealed = k./n;
pa_total    = (pa_hidden.*(50-n) + pa_revealed.*n)/50;

p_u = [p1,p2];  % in un-ambiguous trials   
p_a = [pu,pa_total];  % in ambiguous trials

p = [];
p(uIndx,:)      = p_u(uIndx,:);         
p(aIndx,:)      = p_a(aIndx,:);         
p_bayes = p;

pa_pess = (k+50-n)./n;
p_u = [p1,p2];       % in un-ambiguous trials   
p_a = [pu,pa_pess];  % in ambiguous trials
p_pess = [];
p_pess(uIndx,:)      = p_u(uIndx,:);         
p_pess(aIndx,:)      = p_a(aIndx,:);



pa_opt = k/50;
p_u = [p1,p2];      % in un-ambiguous trials   
p_a = [pu,pa_opt];  % in ambiguous trials
p_opt = [];
p_opt(uIndx,:)      = p_u(uIndx,:);         
p_opt(aIndx,:)      = p_a(aIndx,:);

%%
args.uIndx          = uIndx;
args.aIndx          = aIndx;
args.choice         = choice;    
args.C              = C;    
args.A              = A;  
args.k              = k;
args.n              = n;
args.m              = m;   
args.p              = p; 
args.p_bayes        = p_bayes; 
args.p_pess         = p_pess;
args.p_opt          = p_opt;




%------------------------------------------------------------------
