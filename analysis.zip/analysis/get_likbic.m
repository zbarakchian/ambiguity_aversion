function output = get_likbic(sbjs,model,data,ntrials)

negloglik = [];
if isequal(class(data.data_fit{1}),['GeneralizedLinearModel'])
    for sub = sbjs
        negloglik(sub) = - data.data_fit{sub}.LogLikelihood;
    end
else  %'struct'
    for sub = sbjs
        negloglik(sub) = + data.data_fit{sub}.negloglik;
    end
end
    
output = [];
for sub = sbjs 
    nfpm  = model.parameters.num; %number of free parameter
    
    AIC = 2 * negloglik(sub) + nfpm * 2;    
    BIC = 2 * negloglik(sub) + nfpm * log(ntrials);        
    
    output{sub}.lik = negloglik(sub);  
    output{sub}.aic = AIC;  
    output{sub}.bic = BIC;  
    output{sub}.hessian = data.data_fit{sub}.hessian;
end
