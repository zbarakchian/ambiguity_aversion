function addr = get_address()
%-create necessary folders



folder.bhv                       = 'data';    %sumbhv: summarized behavioral data           
folder.fit                       = 'fitting';             
folder.params                    = 'data_params';             
folder.precovery                 = 'precovery'; %parameter recovery         
folder.gof                       = 'gof';             
folder.simf                      = 'data_simf';      %simf: simulation with fitted parameters           
folder.simp                      = 'data_simp';      %simf: simulation with desired parameters           
folder.identify                  = 'identify'; 

fields = fieldnames(folder);
for i = 1:length(fields)
    output.(fields{i}) = ['results' filesep folder.(fields{i})];
%     mkdir(results.(fields{i}));
end

output.data = ['data'];
addr = output;

