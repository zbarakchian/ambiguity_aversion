function analysis_parameters(addr,sbjs,models)


do_plot         = 1;
do_corr         = 0;
do_corr_score   = 0;



nmodel = length(models);
params = get_params(addr.fit,sbjs,models);

%% plot histogram of parameters
if do_plot
for m = 1:nmodel   
    model = models{m};     
    
    param1  = params.(model.name);   
    np = model.parameters.num;
    
    for p = 1:np
        pnames = model.parameters.name{p};
        f = figure;       
        hist(param1(:,p),10);        
        title(pnames);
        
        set(gca,'FontName','Times New Roman', 'FontSize', 16);

        name = ['figs' filesep 'parameter_' model.name '_' pnames '.png'];
        saveas(gcf,name);
        close(f);
    end
end
end


%% correlation between params
if do_corr

for m = 1:nmodel   
    model = models{m};   
    disp(model.name);

    param1  = params.(model.name);   
    np = model.parameters.num;
    pnames = model.parameters.name;

    for p1 = 1:np     
    for p2 = 1:np     
            pm1 = param1(:,p1);
            pm2 = param1(:,p2);
            [rho,pval] = corr(pm1,pm2); 
            correlations(p1,p2) = rho;
            disp([rho,pval]);            
    end
    end
    
    f = figure;
    heatmap(pnames,pnames,correlations,'ColorLimits',[-1 1]); 
    title(model.name); 
    
    h.YLabel = 'Parameter';
    h.XLabel = 'Parameter';

    colorbar;
    greenColorMap = [zeros(1, 132), linspace(0, 1, 124)]; %% Create colormap that is green for negative, red for positive,and a chunk inthe middle that is black.
    redColorMap = [linspace(1, 0, 124), zeros(1, 132)];
    colorMap = [redColorMap; greenColorMap; zeros(1, 256)]';
    colormap(colorMap); % Apply the colormap.
    
    set(gca,'FontName','Times New Roman', 'FontSize', 16);
    
    name = ['figs' filesep 'parameter_' model.name '.png'];
    saveas(gcf,name);
    close(f);
    


end
end
%% correlation between params and scores
if do_corr_score
    
load([addr.data filesep 'scores.mat']);
scores = TraitAnxietyScores.STAITraitAnxietyScore;

for m = 1:nmodel   
    model = models{m};     
    
    param1  = params.(model.name);   
    np = model.parameters.num;
    pnames = model.parameters.name;
    
    for p = 1:np             
        disp(pnames{p});

        pm = param1(:,p);
        [rho,pval] = corr(scores,pm);%,'Type','Spearman');            
        disp([rho,pval]);

        figure
        scatter(scores,pm,100,'filled');    
        grid on;
        title(pnames{p});
        %xlim([0,1])

        xlabel('Score');
        ylabel('Parameter');

        h = lsline;
        h.Color = 'b';
        h.LineWidth = 5;
    end
end
end



